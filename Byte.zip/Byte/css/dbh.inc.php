<?php

$conn=mysqli_connect('localhost','root','','commentsection2');
   
   if(!$conn)
   die("connection faild: ".mysql_connect_error());

?>